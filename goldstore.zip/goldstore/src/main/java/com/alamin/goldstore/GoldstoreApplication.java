package com.alamin.goldstore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GoldstoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(GoldstoreApplication.class, args);
	}

}
